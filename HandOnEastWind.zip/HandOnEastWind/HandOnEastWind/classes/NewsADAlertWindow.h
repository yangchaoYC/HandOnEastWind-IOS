//
//  NewsADAlertWindow.h
//  HandOnEastWind
//
//  Created by jijeMac2 on 14-3-12.
//  Copyright (c) 2014年 lidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsADAlertWindow : UIWindow
- (void)show:(NSString *)key;
- (void)hide;
@end

//
//  PartnersCell.h
//  HandOnEastWind
//
//  Created by jijeMac2 on 14-3-11.
//  Copyright (c) 2014年 lidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartnersCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *partnersIconImageView;
@property (weak, nonatomic) IBOutlet UILabel *partnersTitleLabel;

@end
